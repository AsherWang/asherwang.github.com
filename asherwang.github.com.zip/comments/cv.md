```  
临时写的一份简历，不太完善还请见谅
```

----


## 联系方式  

- 手机：13146021274  
- Email：mm145m145@gmail.com  
- QQ：1057488870  

---

## 个人信息

 - 王奥鑫/男/1993 
 - 本科/北京航空航天大学软件学院/2016年7月毕业 
 - 工作年限：1年
 - 个人主页：https://asherwang.github.io   
 - 技术类博客：http://blog.csdn.net/fancykitty
 - Github：https://github.com/AsherWang   
 - 期望职位：Web前端高级程序员，全栈工程师  
 - 现居城市：北京 
 - 期望城市：北京

---

## 工作经历

### 北京易汇百川信息科技有限公司（ 2015年6月 ~ 2016年10月 ）

#### 项目：上线易  
　　关键词：Ruby/Rails/MongoDB/微信公众号开发  
　　我2015年6月参与了这个项目“上线易”的开发，项目是一个和微信公众号紧密结合的多租户商城系统。  
　　作为项目的核心程序员，我负责开发的包括前端界面，后端业务逻辑，以及后台调度队列。其中我比较满意的有自己设计实现的前端购物车的缓存机制,调用微信提供的API并在前端完成授权、定位、支付等功能。  
　　在项目中后期为App的开发做准备，还完成了后台的API的开发，其中我负责了Ouath2.0认证机制的实现以及后台大部分API的实现。  

---

## 开源项目和作品

### 开源项目

 - [loado](https://github.com/AsherWang/loado)：Node module，加载一个文件夹下的所有模块，运行并返回自定义的结果  
 - [css3-transform-generator](https://github.com/AsherWang/css3-transform-generator)：sass的mixin，将css的多个transform属性解析成一个矩阵 
 
### 个人作品  
 占位待补

----

## 技能清单

以下均为我熟练使用的技能 

- Web开发：Ruby/Node
- Web框架：Rails/express/koa
- 前端框架：Bootstrap/AngularJS/HTML5/ionic
- 前端工具：Bower/Gulp/Sass/Pug(Jade)/Slim/
- 数据库相关：MySQL/MongoDB/SqlServer
- 版本管理、文档和自动化部署工具：Svn/Git
- 云和开放平台：SAE/微信应用开发


---

## 致谢
感谢您花时间阅读我的简历，期待能有机会和您共事。  
简历将在2天内完善。  

2016年11月03日